class AlreadyLocked(Exception):
    '''
    Exception being thrown if the file descriptor already has been locked.
    '''
    pass


